// main program for the Document Analysis Project

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "unit_tests.h"


// Run the unit tests or as a "normal program".
// You can run this as a "normal program" if you want for a simple test of the sort_two_positions function.
int main( int argc, char *argv[] )
{
	
	test() ;
	
	return 0 ;
}
