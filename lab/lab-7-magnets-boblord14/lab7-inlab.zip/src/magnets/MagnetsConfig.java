package magnets;

import backtracking.Configuration;
import test.IMagnetTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

/**
 * The representation of a magnet configuration, including the ability
 * to backtrack and also give information to the JUnit tester.
 *
 * This implements a more optimal pruning strategy in isValid():
 * - Pair checked each time a new cell is populated
 * - Polarity checked each time a new cell is populated
 * - When last column or row is populated, the pos/neg counts are checked
 *
 * @author RIT CS
 */
public class MagnetsConfig implements Configuration, IMagnetTest {
    /** a cell that has not been assigned a value yet */
    private final static char EMPTY = '.';
    /** a blank cell */
    private final static char BLANK = 'X';
    /** a positive cell */
    private final static char POS = '+';
    /** a negative cell */
    private final static char NEG = '-';
    /** left pair value */
    private final static char LEFT = 'L';
    /** right pair value */
    private final static char RIGHT = 'R';
    /** top pair value */
    private final static char TOP = 'T';
    /** bottom pair value */
    private final static char BOTTOM = 'B';
    /** and ignored count for pos/neg row/col */
    private final static int IGNORED = -1;

    // add private state here
    private static int rowCount;
    private static int colCount;
    private static int[] posRows;
    private static int[] posCols;
    private static int[] negRows;
    private static int[] negCols;
    private static char[][] boardRelations;
    private char[][] boardState;
    private int[] cursorPos;


    /**
     * Read in the magnet puzzle from the filename.  After reading in, it should display:
     * - the filename
     * - the number of rows and columns
     * - the grid of pairs
     * - the initial config with all empty cells
     *
     * @param filename the name of the file
     * @throws IOException thrown if there is a problem opening or reading the file
     */
    public MagnetsConfig(String filename) throws IOException {
        try (BufferedReader in = new BufferedReader(new FileReader(filename))) {
            // read first line: rows cols
            String[] fields = in.readLine().split("\\s+");
            rowCount = Integer.parseInt(fields[0]);
            colCount = Integer.parseInt(fields[1]);
            // read second line: pos rows
            fields = in.readLine().split("\\s+");
            posRows = new int[fields.length];
            for(int i=0;i< fields.length;i++){
                posRows[i] = Integer.parseInt(fields[i]);
            }
            // read third line: pos cols
            fields = in.readLine().split("\\s+");
            posCols = new int[fields.length];
            for(int i=0;i< fields.length;i++){
                posCols[i] = Integer.parseInt(fields[i]);
            }
            // read fourth line: neg rows
            fields = in.readLine().split("\\s+");
            negRows = new int[fields.length];
            for(int i=0;i< fields.length;i++){
                negRows[i] = Integer.parseInt(fields[i]);
            }
            // read fifth line: pos rows
            fields = in.readLine().split("\\s+");
            negCols = new int[fields.length];
            for(int i=0;i< fields.length;i++){
                negCols[i] = Integer.parseInt(fields[i]);
            }
            // read rest of file: magnet relations
            boardRelations = new char[rowCount][colCount];
            for(int i=0;i<rowCount;i++){
                fields = in.readLine().split("\\s+");
                for(int j=0;j< fields.length;j++){
                    boardRelations[i][j] = fields[j].charAt(0);
                }
            }
            // initialize the empty board state
            // note for states: E is empty, P is positive, N is negative, S is null
            boardState = new char[rowCount][colCount];
            for(int i=0;i<rowCount;i++){
                for(int j=0;j< colCount;j++){
                    boardState[i][j] = EMPTY;
                }
            }
            // initialize cursor location, stores (row, col) of cursor
            cursorPos = new int[2];
            cursorPos[0] = 0;
            cursorPos[1] = -1;
        } // <3 Jim
    }

    /**
     * The copy constructor which advances the cursor, creates a new grid,
     * and populates the grid at the cursor location with val
     * @param other the board to copy
     * @param val the value to store at new cursor location
     */
    private MagnetsConfig(MagnetsConfig other, char val) {
        boardState = new char[rowCount][colCount];
        for(int i=0;i<rowCount;i++){
            for(int j=0;j< colCount;j++){
                boardState[i][j] = other.getVal(i, j);
            }
        }
        cursorPos = new int[2];
        cursorPos[0] = other.getCursorRow();
        cursorPos[1] = other.getCursorCol();
        cursorPos[1]++;
        if(cursorPos[1]==colCount){
            cursorPos[1] = 0;
            cursorPos[0]++;
        }
        if(cursorPos[0]!=rowCount) {
            boardState[cursorPos[0]][cursorPos[1]] = val;
        }
    }


    /**
     * Generate the successor configs.  For minimal pruning, this should be
     * done in the order: +, - and X.
     *
     * @return the collection of successors
     */
    @Override
    public List<Configuration> getSuccessors() {
        List<Configuration> successors = new ArrayList<>();
        successors.add(new MagnetsConfig(this, '+'));
        successors.add(new MagnetsConfig(this, '-'));
        successors.add(new MagnetsConfig(this, 'X'));
        return successors;
    }


    /**
     * Checks to make sure a successor is valid or not.  For minimal pruning,
     * each newly placed cell at the cursor needs to make sure its pair
     * is valid, and there is no polarity violation.  When the last cell is
     * populated, all row/col pos/negative counts are checked.
     *
     * @return whether this config is valid or not
     */
    @Override
    public boolean isValid() {
        // TODO
        return false;
    }

    @Override
    public boolean isGoal() {
        // TODO
        return false;
    }

    /**
     * Returns a string representation of the puzzle including all necessary info.
     *
     * @return the string
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        // top row
        result.append("+ ");
        for (int col = 0; col < getCols(); ++col) {
            result.append(getPosColCount(col) != IGNORED ? getPosColCount(col) : " ");
            if (col < getCols() - 1) {
                result.append(" ");
            }
        }
        result.append(System.lineSeparator());
        result.append("  ");
        for (int col = 0; col < getCols(); ++col) {
            if (col != getCols() - 1) {
                result.append("--");
            } else {
                result.append("-");
            }
        }
        result.append(System.lineSeparator());

        // middle rows
        for (int row = 0; row < getRows(); ++row) {
            result.append(getPosRowCount(row) != IGNORED ? getPosRowCount(row) : " ").append("|");
            for (int col = 0; col < getCols(); ++col) {
                result.append(getVal(row, col));
                if (col < getCols() - 1) {
                    result.append(" ");
                }
            }
            result.append("|").append(getNegRowCount(row) != IGNORED ? getNegRowCount(row) : " ");
            result.append(System.lineSeparator());
        }

        // bottom row
        result.append("  ");
        for (int col = 0; col < getCols(); ++col) {
            if (col != getCols() - 1) {
                result.append("--");
            } else {
                result.append("-");
            }
        }
        result.append(System.lineSeparator());

        result.append("  ");
        for (int col = 0; col < getCols(); ++col) {
            result.append(getNegColCount(col) != IGNORED ? getNegColCount(col) : " ").append(" ");
        }
        result.append(" -").append(System.lineSeparator());
        return result.toString();
    }

    // IMagnetTest

    @Override
    public int getRows() {
        return rowCount;
    }

    @Override
    public int getCols() {
        return colCount;
    }

    @Override
    public int getPosRowCount(int row) {
        return posRows[row];
    }

    @Override
    public int getPosColCount(int col) {
        return posCols[col];
    }

    @Override
    public int getNegRowCount(int row) {
        return negRows[row];
    }

    @Override
    public int getNegColCount(int col) {
        return negCols[col];
    }

    @Override
    public char getPair(int row, int col) {
        return boardRelations[row][col];
    }

    @Override
    public char getVal(int row, int col) {
        return boardState[row][col];
    }

    @Override
    public int getCursorRow() {
        return cursorPos[0];
    }

    @Override
    public int getCursorCol() {
        return cursorPos[1];
    }
}
