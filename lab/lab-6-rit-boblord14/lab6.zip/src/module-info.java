module RIT {
    requires transitive javafx.controls;
    exports rit;
}