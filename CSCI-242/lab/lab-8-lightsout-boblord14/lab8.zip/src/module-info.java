/**
 * Module description required for some systems to use of JavaFX.
 * YOU MAY RENAME THE MODULE.
 * @author RIT CS
 * November 2022
 */
module LightsOut {
    requires transitive javafx.controls;
    exports gui;
}
