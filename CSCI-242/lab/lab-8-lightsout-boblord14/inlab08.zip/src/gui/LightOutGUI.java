package gui;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.LightsOutModel;
import model.Observer;


public class LightOutGUI extends Application implements Observer {
    private LightsOutModel model;
    private Label moveLabel;
    private Label msgLabel;

    private static final Background WHITE =
            new Background( new BackgroundFill(Color.WHITE, null, null));

    private static final Background BLACK =
            new Background( new BackgroundFill(Color.BLACK, null, null));
    @Override
    public void start(Stage stage) throws Exception {
        this.moveLabel = new Label("Moves: ");
        this.msgLabel = new Label("Hint: ");
        BorderPane borderPane = new BorderPane();

        FlowPane labelPane = new FlowPane(this.moveLabel, this.msgLabel);
        this.moveLabel.setAlignment(Pos.TOP_LEFT);
        this.moveLabel.setAlignment(Pos.TOP_RIGHT);
        borderPane.setTop(labelPane);

        GridPane gridPane = makeGridPane();
        gridPane.setAlignment(Pos.CENTER);
        borderPane.setCenter(gridPane);

        FlowPane buttonPane = new FlowPane(new Button("New Game"), new Button("Load Game"), new Button("Hint"));
        buttonPane.setAlignment(Pos.BOTTOM_CENTER);
        borderPane.setBottom(buttonPane);

        Scene scene = new Scene(borderPane);
        stage.setTitle("Lights Out!");
        stage.setScene(scene);
        stage.setWidth(500);
        stage.setHeight(600);
        stage.setResizable(false);
        stage.show();
    }

    private GridPane makeGridPane(){
        GridPane gridPane = new GridPane();
        for(int row=0;row< model.getDimension();row++){
            for(int col=0;col< model.getDimension();col++){
                Button button = new Button();
                button.setBorder(new Border(new BorderStroke(Color.DARKGRAY, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(2.5))));
                button.setMinSize(100, 100);
                Boolean active= (model.getTile(col, row).isOn());
                if(active){
                    button.setBackground(BLACK);
                }else{
                    button.setBackground(WHITE);
                }
                int finalRow = row;//intellij didnt like this unless i put these in, i dont mind but whatever
                int finalCol = col;
                button.setOnAction(event ->{
                    System.out.println("model hit on " + finalCol +" and " + finalRow);
                    System.out.println("Change from " + model.getTile(finalCol, finalRow).isOn() + " to");
                    model.toggleTile(finalCol, finalRow);
                    if(model.getTile(finalCol, finalRow).isOn()){
                        button.setBackground(WHITE);
                    }else{
                        button.setBackground(BLACK);
                    }
                    System.out.println(model.getTile(finalCol, finalRow).isOn());
                }
                );
                gridPane.add(button, col, row);
            }
        }
        return gridPane;
    }
    @Override
    public void init() throws Exception {
        this.model = new LightsOutModel();
        model.addObserver(this);
        System.out.println("init: Initialize and connect to model!");
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void update(Object o, Object o2) {
        model = (LightsOutModel) o;
    }
}
