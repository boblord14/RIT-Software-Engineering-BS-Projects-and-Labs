package toys;

public abstract class BatteryPowered extends Toy{

    final static int FULLY_CHARGED = 100;
    final static int DEPLETED = 0;
    protected BatteryPowered(int productCode, String name, int batteryNum){ super(productCode, name); }

    public int getBatteryLevel(){ return 0; }

    public int getNumBatteries(){ return 0; }

    protected void useBatteries(){}

    @Override
    public String toString(){ return null; }

}
