package toys;

public class ActionFigure extends Doll {
    private static int afCode = 300;
    protected ActionFigure(String name, int age, String speak) {
        super(afCode, name, Color.ORANGE, age, speak);
    }

    public int getEnergyLevel(){ return 0; }

    @Override
    protected void specialPlay(int time){}

    @Override
    public String toString(){ return null; }
}
