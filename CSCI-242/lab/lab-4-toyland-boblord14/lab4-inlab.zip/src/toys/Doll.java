package toys;

public class Doll extends Toy{
    private static int dollCode = 200;

    protected Doll(String name, Color hairColor, int age, String speak){
        super(dollCode, name);
    }

    protected Doll(int productCode, String name, Color hairColor, int age, String speak){super(productCode, name);}

    public Color getHairColor(){ return null; }

    public int getAge(){ return 0; }

    public String getSpeak(){ return null; }

    @Override
    protected void specialPlay(int time) {}

    @Override
    public String toString(){ return null; }

}
