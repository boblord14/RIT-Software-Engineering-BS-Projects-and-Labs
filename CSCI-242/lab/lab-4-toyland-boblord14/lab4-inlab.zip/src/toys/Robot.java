package toys;

public class Robot extends BatteryPowered{

    final static int FLY_SPEED = 25;
    final static int RUN_SPEED = 10;
    final static int INITIAL_SPEED = 0;

    private static int robotCode = 500;

    protected Robot(String name, int batteryNum, boolean doesFly){ super(robotCode, name, batteryNum); }

    public boolean isFlying(){ return false; }

    public int getDistance(){ return 0; }

    @Override
    protected void specialPlay(int time) {}

    @Override
    public String toString(){ return null; }
}
