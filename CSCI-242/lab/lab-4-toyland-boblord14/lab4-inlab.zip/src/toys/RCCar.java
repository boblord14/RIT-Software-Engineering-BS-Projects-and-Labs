package toys;

public class RCCar extends BatteryPowered{

    final static int STARTING_SPEED = 10;
    final static int SPEED_INCREASE = 5;

    private static int RCCode = 400;

    protected RCCar(String name, int batteryNum){ super(RCCode, name, batteryNum); }

    public int getSpeed(){ return 0; }

    @Override
    protected void specialPlay(int time){}

    @Override
    public String toString(){ return null; }
}
