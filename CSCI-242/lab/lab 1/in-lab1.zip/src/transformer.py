"""
CSAPX Lab 1: Secret Messages

A program that encodes/decodes a message by applying a set of transformation operations.
The transformation operations are:
    shift - Sa[,n] changes letter at index a by moving it n letters fwd in the alphabet. A negative
        value for n shifts the letter backward in the alphabet.
    rotate - R[n] rotates the string n positions to the right. A negative value for n rotates the string
        to the left.
    duplicate - Da[,n] follows character at index a with n copies of itself.

All indices numbers (the subscript parameters) are 0-based.

author: Ethan Patterson
"""


# the entire framework for the op functions is present, all that's missing is the functions themselves

# the following 4 operations are roughly identical in general structure,
# they take the op param and compute what it means on the string param, then returns whatever the new string is

def shiftOp(op, string):
    # code for shift goes here
    pass


def rotateOp(op, string):
    # code for rotate goes here
    pass


def duplicateOp(op, string):
    # code for duplicate goes here
    pass


def tradeOp(op, string):
    # code for trade goes here
    pass


def transform(rawOps, rawString):
    finalString = rawString
    opList = rawOps.split(';')
    for op in opList:
        if op[0] == "S":
            print("Operation Shift (S) - Parameters: " + op[1:])
            finalString = shiftOp(op, finalString)
        elif op[0] == "R":
            print("Operation Rotate (R) - Parameters: " + op[1:])
            finalString = rotateOp(op, finalString)
        elif op[0] == "D":
            print("Operation Duplicate (D) - Parameters: " + op[1:])
            finalString = duplicateOp(op, finalString)
        elif op[0] == "T":
            print("Operation Trade (T) - Parameters: " + op[1:])
            finalString = tradeOp(op, finalString)
        else:
            print(op + " is an invalid operator, check over your inputs and try again")
            break


def computeStart():
    initialString = input('Enter the message: ')
    transformOps = input('Enter the encrypting transformation operations: ')
    print("Generating output...")
    print("Transforming message: " + initialString)
    print("Applying...")
    transform(transformOps, initialString)


def main() -> None:
    print("Welcome to Secret Messages!")
    while True:
        initialCommand = input('What do you want to do: (E)ncrypt, (D)ecrypt or (Q)uit? ')
        if (initialCommand == "E") or (initialCommand == "D"):
            computeStart()
        elif initialCommand == "Q":
            print("Goodbye!")
            break
        else:
            print("Invalid task, please try again")


if __name__ == '__main__':
    main()
