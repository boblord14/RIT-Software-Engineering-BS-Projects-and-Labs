module BFSPuzzleSolver {
    requires transitive javafx.controls;
    exports puzzles.common;
    exports puzzles.common.solver;
    exports puzzles.tilt.gui;
    exports puzzles.tilt.model;
    exports puzzles.jam.gui;
    exports puzzles.jam.model;
}